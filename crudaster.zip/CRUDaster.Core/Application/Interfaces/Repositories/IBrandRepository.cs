﻿using CRUDaster.Core.Domain.Entities;

namespace CRUDaster.Core.Application.Interfaces.Repositories
{
    public interface IBrandRepository : IRepository<Brand>
    {
    }
}
