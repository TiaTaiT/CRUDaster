﻿using CRUDaster.Core.Domain.Entities;

namespace CRUDaster.Core.Application.Interfaces.Repositories
{
    public interface IPimRepository : IRepository<Pim>
    {
    }
}
