﻿using CRUDaster.Core.Domain.Entities.AppUserRights;

namespace CRUDaster.Core.Application.Interfaces.Repositories
{
    public interface IFunctionalityRepository : IRepository<Functionality>
    {
    }
}
