﻿namespace CRUDaster.ExternalServices.Interfaces
{
    public interface IClass1
    {
    }
}
